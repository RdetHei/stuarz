<?php
require_once dirname(__DIR__) . '/config/config.php';
class ProfileController
{
    public function profile()
    {
        global $config;
        if (session_status() === PHP_SESSION_NONE) session_start();

        $userId = $_SESSION['user_id'] ?? null;
        if (!$userId) {
            header("Location: index.php?page=login");
            exit;
        }

        $stmt = mysqli_prepare($config, "SELECT * FROM users WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $userId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $user = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        if ($user) {
            $_SESSION['user'] = $user;
        }

        $title = "Profile - Stuarz";
        $description = "Your profile details";
        $content = dirname(__DIR__) . '/views/pages/profile.php';
        include dirname(__DIR__) . '/views/layouts/dLayout.php';
    }
}

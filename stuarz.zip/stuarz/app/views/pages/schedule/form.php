
<?php
// $mode = 'create'|'edit', $item, $days, $classes, $subjects, $teachers
$error = $_SESSION['error'] ?? null;
unset($_SESSION['error']);
$action = $mode === 'create' ? '/schedule/store' : "/schedule/update/{$item['id']}";
?>
<h2><?= $mode === 'create' ? 'Tambah Jadwal' : 'Edit Jadwal' ?></h2>
<?php if ($error): ?><p style="color:red"><?= htmlspecialchars($error) ?></p><?php endif; ?>
<form method="post" action="<?= $action ?>">
    <label>Kelas (nama)<br><input name="class" value="<?= htmlspecialchars($item['class'] ?? '') ?>"></label><br>
    <label>Class ID (pilih)<br>
        <select name="class_id">
            <option value="">--pilih--</option>
            <?php foreach ($classes as $c): ?>
                <option value="<?= $c['id'] ?>" <?= (isset($item['class_id']) && $item['class_id']==$c['id'])? 'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label><br>
    <label>Subject<br>
        <select name="subject">
            <option value="">--pilih--</option>
            <?php foreach ($subjects as $s): ?>
                <option value="<?= htmlspecialchars($s['name']) ?>" <?= (isset($item['subject']) && $item['subject']==$s['name'])? 'selected':'' ?>><?= htmlspecialchars($s['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label><br>
    <label>Guru<br>
        <select name="teacher_id">
            <option value="">--pilih--</option>
            <?php foreach ($teachers as $t): ?>
                <option value="<?= $t['id'] ?>" <?= (isset($item['teacher_id']) && $item['teacher_id']==$t['id'])? 'selected':'' ?>><?= htmlspecialchars($t['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label><br>
    <label>Hari<br>
        <select name="day">
            <?php foreach ($days as $d): ?>
                <option value="<?= $d ?>" <?= (isset($item['day']) && $item['day']==$d)? 'selected':'' ?>><?= $d ?></option>
            <?php endforeach; ?>
        </select>
    </label><br>
    <label>Mulai<br><input type="time" name="start_time" value="<?= htmlspecialchars($item['start_time'] ?? '') ?>"></label><br>
    <label>Selesai<br><input type="time" name="end_time" value="<?= htmlspecialchars($item['end_time'] ?? '') ?>"></label><br>
    <button type="submit"><?= $mode === 'create' ? 'Simpan' : 'Update' ?></button>
</form>

<h2>Jadwal</h2>
<a href="/schedule/create">Tambah Jadwal</a>
<table border="1" cellpadding="6">
    <thead>
        <tr><th>ID</th><th>Kelas</th><th>Subject</th><th>Guru</th><th>Hari</th><th>Jam</th><th>Aksi</th></tr>
    </thead>
    <tbody>
    <?php foreach ($schedules as $s): ?>
        <?php
           $teacherName = '';
           if (!empty($s['teacher_id'])) {
               $tres = $this->db->query("SELECT name FROM users WHERE id=" . intval($s['teacher_id']));
               $tn = $tres ? $tres->fetch_assoc() : null;
               $teacherName = $tn['name'] ?? '';
           }
        ?>
        <tr>
            <td><?= htmlspecialchars($s['id']) ?></td>
            <td><?= htmlspecialchars($s['class']) ?></td>
            <td><?= htmlspecialchars($s['subject']) ?></td>
            <td><?= htmlspecialchars($teacherName) ?></td>
            <td><?= htmlspecialchars($s['day']) ?></td>
            <td><?= htmlspecialchars($s['start_time']) ?> - <?= htmlspecialchars($s['end_time']) ?></td>
            <td>
                <a href="/schedule/edit/<?= $s['id'] ?>">Edit</a>
                <form method="post" action="/schedule/delete/<?= $s['id'] ?>" style="display:inline" onsubmit="return confirm('Hapus?')">
                    <button type="submit">Hapus</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
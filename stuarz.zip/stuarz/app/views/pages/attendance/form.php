<?php
// $classes, $students, $date
?>
<h2>Tandai Absensi</h2>
<form method="get" action="/attendance/mark">
    <label>Kelas:
        <select name="class_id" onchange="this.form.submit()">
            <option value="">--pilih--</option>
            <?php foreach ($classes as $c): ?>
                <option value="<?= $c['id'] ?>" <?= (isset($_GET['class_id']) && $_GET['class_id']==$c['id'])? 'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Tanggal: <input type="date" name="date" value="<?= htmlspecialchars($date) ?>"></label>
</form>

<?php if (!empty($students)): ?>
<form method="post" action="/attendance/store">
    <input type="hidden" name="class_id" value="<?= intval($_GET['class_id']) ?>">
    <input type="hidden" name="date" value="<?= htmlspecialchars($date) ?>">
    <table border="1" cellpadding="6">
        <thead><tr><th>Siswa</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($students as $s): 
            $existing = $this->db->query("SELECT status FROM attendance WHERE user_id=" . intval($s['id']) . " AND date='" . $this->db->real_escape_string($date) . "' AND class_id=" . intval($_GET['class_id']))->fetch_assoc();
            $cur = $existing['status'] ?? '';
        ?>
            <tr>
                <td><?= htmlspecialchars($s['name']) ?><input type="hidden" name="user_id[]" value="<?= $s['id'] ?>"></td>
                <td>
                    <select name="status[]">
                        <option value="Hadir" <?= $cur=='Hadir'?'selected':'' ?>>Hadir</option>
                        <option value="Absen" <?= $cur=='Absen'?'selected':'' ?>>Absen</option>
                        <option value="Terlambat" <?= $cur=='Terlambat'?'selected':'' ?>>Terlambat</option>
                    </select>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <button type="submit">Simpan Absensi</button>
</form>
<?php endif; ?>
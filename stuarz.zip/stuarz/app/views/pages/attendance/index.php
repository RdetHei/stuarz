<?php
// demo values
$stats = [
  ['title' => 'Present Days', 'value' => 20, 'color' => 'success', 'icon' => 'check'],
  ['title' => 'Absent Days',  'value' => 2,  'color' => 'danger',  'icon' => 'x'],
  ['title' => 'Late Days',    'value' => 3,  'color' => 'warning','icon' => 'clock'],
];
?>

<div class="max-w-[1400px] mx-auto p-4 lg:p-6">
  <!-- Stats grid -->
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <?php foreach ($stats as $s): ?>
    <div class="bg-[#2b2d31] border border-[#3f4147] rounded-xl p-5 flex items-center justify-between">
      <div>
        <div class="text-sm text-gray-300/80 mb-1"><?= htmlspecialchars($s['title']) ?></div>
        <div class="text-3xl font-bold text-white"><?= (int)$s['value'] ?> days</div>
      </div>
      <div class="w-12 h-12 rounded-lg flex items-center justify-center <?php
        echo $s['color']==='success' ? 'bg-emerald-500/20 text-emerald-300' : ($s['color']==='danger' ? 'bg-red-500/20 text-red-300' : 'bg-orange-500/20 text-orange-300');
      ?>">
        <!-- simple icons -->
        <?php if ($s['icon']==='check'): ?>
          <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <?php elseif ($s['icon']==='x'): ?>
          <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12" stroke-linecap="round"/></svg>
        <?php else: ?>
          <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 6v6l4 2" stroke-linecap="round"/><circle cx="12" cy="12" r="9"/></svg>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Check-in/out card -->
  <div class="bg-[#2b2d31] border border-[#3f4147] rounded-xl p-6 mt-4">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
      <div>
        <div class="text-sm text-gray-300/80">Current Time</div>
        <div id="attClock" class="text-4xl font-bold tracking-tight text-white">00:00:00</div>
        <div class="mt-1 text-sm" id="attStatus"><span class="px-2 py-1 rounded-full text-xs bg-red-500/20 text-red-300 border border-red-500/30">Not Checked In</span></div>
      </div>
      <div class="flex items-center gap-3">
        <div class="text-sm text-gray-300/80">Checked in at:</div>
        <div id="attCheckinTime" class="text-white font-medium">-</div>
      </div>
      <div>
        <button id="attActionBtn" class="px-6 py-3 rounded-lg font-semibold transition text-white bg-gradient-to-tr from-indigo-500 to-purple-500">Check In</button>
      </div>
    </div>
  </div>

  <!-- Attendance table -->
  <div class="bg-[#2b2d31] border border-[#3f4147] rounded-xl p-6 mt-4">
    <div class="text-white font-semibold mb-3">Recent Attendance</div>
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="text-left text-gray-300/80">
          <tr>
            <th class="py-2 pr-4 font-medium">Date</th>
            <th class="py-2 pr-4 font-medium">Check In</th>
            <th class="py-2 pr-4 font-medium">Check Out</th>
            <th class="py-2 pr-4 font-medium">Duration</th>
            <th class="py-2 pr-4 font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          <?php for ($i=0; $i<5; $i++): $date = date('Y-m-d', strtotime("-$i day")); ?>
          <tr class="table-row-hover">
            <td class="py-2 pr-4 text-[#e5e7eb]"><?= $date ?></td>
            <td class="py-2 pr-4 flex items-center gap-1 text-gray-200">
              <svg class="w-4 h-4 opacity-70" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 6v6l4 2" stroke-linecap="round"/><circle cx="12" cy="12" r="9"/></svg>
              08:0<?= 5+$i ?>
            </td>
            <td class="py-2 pr-4 flex items-center gap-1 text-gray-200">
              <svg class="w-4 h-4 opacity-70" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 6v6l4 2" stroke-linecap="round"/><circle cx="12" cy="12" r="9"/></svg>
              16:3<?= $i ?>
            </td>
            <td class="py-2 pr-4 text-gray-200">8h <?= $i ?>m</td>
            <td class="py-2 pr-4">
              <?php if ($i===1): ?><span class="px-2 py-1 rounded-full text-xs bg-red-500/20 text-red-300 border border-red-500/30">Absent</span>
              <?php elseif ($i===2): ?><span class="px-2 py-1 rounded-full text-xs bg-orange-500/20 text-orange-300 border border-orange-500/30">Late</span>
              <?php else: ?><span class="px-2 py-1 rounded-full text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Present</span><?php endif; ?>
            </td>
          </tr>
          <?php endfor; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div id="attToast" class="toast">Saved</div>

<script>
(function(){
  const clock = document.getElementById('attClock');
  const statusEl = document.getElementById('attStatus');
  const checkinTimeEl = document.getElementById('attCheckinTime');
  const btn = document.getElementById('attActionBtn');
  const toast = document.getElementById('attToast');
  let checkedIn = false;
  let checkinAt = null;

  function tick(){
    const d = new Date();
    const pad = n => String(n).padStart(2,'0');
    clock.textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  setInterval(tick, 1000); tick();

  function showToast(msg){
    toast.textContent = msg; toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'), 1600);
  }

  function render(){
    if (checkedIn){
      statusEl.innerHTML = '<span class="badge badge-success">Checked In</span>';
      btn.textContent = 'Check Out';
      btn.classList.remove('btn-gradient');
      btn.classList.add('btn-danger');
      checkinTimeEl.textContent = checkinAt ? new Date(checkinAt).toLocaleTimeString() : '-';
    } else {
      statusEl.innerHTML = '<span class="badge badge-danger">Not Checked In</span>';
      btn.textContent = 'Check In';
      btn.classList.remove('btn-danger');
      btn.classList.add('btn-gradient');
      checkinTimeEl.textContent = '-';
    }
  }

  btn.addEventListener('click', function(){
    if (!checkedIn){ checkedIn = true; checkinAt = Date.now(); showToast('Checked in successfully'); }
    else { checkedIn = false; showToast('Checked out successfully'); }
    render();
  });

  render();
})();
</script>


<h2>Daftar Absensi</h2>
<form method="get" action="/attendance">
    <label>Kelas:
        <select name="class_id">
            <option value="">Semua</option>
            <?php foreach ($classes as $c): ?>
                <option value="<?= $c['id'] ?>" <?= (isset($_GET['class_id']) && $_GET['class_id']==$c['id'])? 'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Tanggal: <input type="date" name="date" value="<?= htmlspecialchars($_GET['date'] ?? '') ?>"></label>
    <button type="submit">Filter</button>
</form>
<table border="1" cellpadding="6">
    <thead><tr><th>Tanggal</th><th>Siswa</th><th>Kelas</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($records as $r): ?>
        <?php
            $className = '';
            if (!empty($r['class_id'])) {
                $cres = $this->db->query("SELECT name FROM classes WHERE id=" . intval($r['class_id']));
                $cn = $cres ? $cres->fetch_assoc() : null;
                $className = $cn['name'] ?? '';
            }
        ?>
        <tr>
            <td><?= htmlspecialchars($r['date']) ?></td>
            <td><?= htmlspecialchars($r['student_name'] ?? '') ?></td>
            <td><?= htmlspecialchars($className) ?></td>
            <td><?= htmlspecialchars($r['status']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<a href="/attendance/mark">Tandai Absensi</a> | <a href="/attendance/report">Laporan</a>

<h2>Laporan Absensi</h2>
<form method="get" action="/attendance/report">
    <label>Siswa:
        <select name="user_id">
            <option value="">--pilih--</option>
            <?php foreach ($students as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (isset($_GET['user_id']) && $_GET['user_id']==$s['id'])? 'selected':'' ?>><?= htmlspecialchars($s['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Dari: <input type="date" name="from" value="<?= htmlspecialchars($_GET['from'] ?? '') ?>"></label>
    <label>Sampai: <input type="date" name="to" value="<?= htmlspecialchars($_GET['to'] ?? '') ?>"></label>
    <button type="submit">Tampilkan</button>
</form>

<?php if ($report !== null): ?>
    <h3>Rekap</h3>
    <ul>
        <li>Hadir: <?= $report['Hadir'] ?? 0 ?></li>
        <li>Absen: <?= $report['Absen'] ?? 0 ?></li>
        <li>Terlambat: <?= $report['Terlambat'] ?? 0 ?></li>
    </ul>
    <?php
    $total = array_sum($report);
    if ($total > 0) {
        echo "<h4>Persentase</h4>";
        foreach ($report as $k=>$v) {
            $p = round($v / $total * 100, 1);
            echo "<div>$k: $p%</div>";
        }
    }
    ?>
<?php endif; ?>
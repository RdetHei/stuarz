<a href="#" class="-m-1.5 p-1.5">
  <span class="sr-only">Your Company</span>
  <svg fill="#ffffff" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" 
       xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 293.538 293.538" 
       xml:space="preserve" stroke="#ffffff" class="h-8 w-8">
    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
    <g id="SVGRepo_iconCarrier"> 
      <g> 
        <g> 
          <polygon points="210.084,88.631 146.622,284.844 81.491,88.631 "></polygon> 
          <polygon points="103.7,64.035 146.658,21.08 188.515,64.035 "></polygon> 
          <polygon points="55.581,88.631 107.681,245.608 0,88.631 "></polygon> 
          <polygon points="235.929,88.631 293.538,88.631 184.521,247.548 "></polygon> 
          <polygon points="283.648,64.035 222.851,64.035 168.938,8.695 219.079,8.695 "></polygon> 
          <polygon points="67.563,8.695 124.263,8.695 68.923,64.035 7.969,64.035 "></polygon> 
        </g> 
      </g> 
    </g>
  </svg>
</a>